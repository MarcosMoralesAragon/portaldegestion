package modelos;

public class Operario extends Empleado{

    public Operario(String n) {
        super(n);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
