package modelos;

public class Oficial  extends Operario{

    public Oficial(String n) {
        super(n);
    }

    @Override
    public String toString() {
        return super.toString();
    }

}
